#! /bin/bash
python3 decoder.py $1 $2 $3