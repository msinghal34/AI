#! /bin/bash
python3 valueiteration.py $1